//////////////////////////////////
//                              //
//   BktGlitch 1.2              //
//    Written by Blokatt        //
//     (Jan Vorisek)            //
//      @blokatt | blokatt.net  //
//       jan@blokatt.net        //
//        26/12/2017            //
//                              //
//////////////////////////////////

-- - = = itch.io edition = = - --

//////////////////////////////////

Please provide credit if you end up
using this shader in anything!
(You don't have to if you paid for it, though.)

Also don't resell, redistribute, etc.

If you'd like to support me, you can do so at:
- https://marketplace.yoyogames.com/assets/5728/bktglitch -
or
- https://blokatt.itch.io/bktglitch -

Thank you.

//////////////////////////////////

Press C in the demo to get the code of your current configuration.

See Draw GUI of objControl for setup instructions.
Easier example available in objSimpleExample, change the room order to see it in action.

I recommend you use the provided setup GML scripts (see "BktGlitch" in Scripts) to control the
shader rather then accessing the uniforms directly, this requires you run "BktGlitch_init()"
at the start of the game. 

If you don't want to set over 10 properties manually, you can use one of the available presets - see "BktGlitch_config_preset()".

Have fun!


